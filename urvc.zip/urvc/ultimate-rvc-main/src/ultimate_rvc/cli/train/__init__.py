"""
Package which defines voice model training commands for the CLI of the
Ultimate RVC project.
"""
