"""
Package which defines models for representing UI component and event
configurations.
"""
